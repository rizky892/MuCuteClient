## MuCuteClient : An Utility Client for Android

<img src="images/logo.png" alt="Logo" width="30%" />

Relay: https://github.com/RadiantByte/MuCuteRelay

## License

GNU GENERAL PUBLIC LICENSE  Version 3

## Special Thanks to:

CaiMuCheng (Package, UI & Relay)

LodingGlue (Modules)

MrPokeG (Modules & UI)

Answer2 (Functions)

KATZEYEUEU (Kawaii Theme)

Hax0r (Partial ProtoHax Source Code)
https://github.com/hax0r31337

Wlenk
https://github.com/Wlenk
