package com.mucheng.mucute.client.util

object MinecraftUtils {
    const val RECOMMENDED_VERSION = "v1.21.62"
}